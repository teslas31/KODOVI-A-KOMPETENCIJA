﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;

namespace Telefonski_Imenik
{
    public partial class Imenik1 : System.Web.UI.Page
    {
        List<Imenik> lista = new List<Imenik>();
        List<string> gradovi = new List<string>();
        int t1=0, t2=0, t3=0, t4=0,t5=0;
        protected void Page_Load(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(MapPath("TelefonskiImenik.txt"), true);
            string s = sr.ReadLine();
            string id, ime, prezime, adresa, mesto, broj, mail;
            while (s != null)
            {
                int p = s.IndexOf('|');
                id = s.Substring(0, p - 1);
                s = s.Substring(p + 2);
                int p2 = s.IndexOf('|');
                ime = s.Substring(0, p2 - 1);
                s = s.Substring(p2 + 2);
                int p3 = s.IndexOf('|');
                prezime = s.Substring(0, p3 - 1);
                s = s.Substring(p3 + 2);
                int p4 = s.IndexOf('|');
                adresa = s.Substring(0, p4 - 1);
                s = s.Substring(p4 + 2);
                int p5 = s.IndexOf('|');
                mesto = s.Substring(0, p5 - 1);
                s = s.Substring(p5 + 2);
                int p6 = s.IndexOf('|');
                broj = s.Substring(0, p6 - 1);
                mail = s.Substring(p6 + 2);
                Imenik im = new Imenik(id, ime, prezime, adresa, mesto, broj, mail);
                lista.Add(im);
                s = sr.ReadLine();
            }
            if (!Page.IsPostBack)
            {
                foreach (var a in lista)
                {
                    gradovi.Add(a.Mesto);
                }
                foreach (var b in gradovi.Distinct())
                { DropDownList1.Items.Add(b); }
            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
            t1 = 1;

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {
            t2 = 1;
        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {
            t3 = 1;
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            t4 = 1;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Vaznitelefoni.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Korisnickouputstvo.aspx");
        }

        protected void TextBox4_TextChanged(object sender, EventArgs e)
        {
            t5 = 1;

        }

        protected void Button3_Click(object sender, EventArgs e)
        {

            string ime = TextBox1.Text;
            string prezime = TextBox2.Text;
            string adresa = TextBox3.Text;
            string mesto = DropDownList1.SelectedValue.ToString();
            string broj = TextBox4.Text;
            PlaceHolder1.Controls.Add(new LiteralControl("<table id='korisnici'>"));
            PlaceHolder1.Controls.Add(new LiteralControl("<tr><th>Id</th><th>Ime</th><th>Prezime</th><th>Adresa</th><th>Mesto</th><th>Broj</th><th>E-mail</th></tr>"));
            foreach (var a in lista)
            {
                if ((a.Ime.Contains(ime) || ime == "") && (a.Prezime.Contains(prezime) || prezime == "") && (a.Adresa.Contains(adresa) || adresa == "") && (a.Mesto == mesto || mesto == "Izaberi") && (a.Broj.Contains(broj) || broj==""))
                    {
                        PlaceHolder1.Controls.Add(new LiteralControl(string.Format("<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td><td>{6}</td></tr>", a.Id, a.Ime, a.Prezime, a.Adresa, a.Mesto, a.Broj, a.Mail)));
                    }
                   
                }
                PlaceHolder1.Controls.Add(new LiteralControl("</table>"));
            }
         
        
    }
}