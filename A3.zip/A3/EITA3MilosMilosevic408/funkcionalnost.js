function promeni()
{
	var pom = document.getElementById("gradovi");
	document.getElementById("ifrm").src = "https://naslovi.net/vremenska-prognoza/" + pom.value;
}